package algorithms;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Random;

import tools.Rectangle;
import tools.Vecteur;
import tools.Circle;
import tools.EnveloppeConvexe;
import tools.Line;
import tools.Other;
public class DefaultTeam {

	/*
	 * ***************************
	 * Algorithme de Toussaint   *
	 * ***************************
	 */

	
	public Rectangle toussaint(ArrayList<Point> enveloppe){  //En parametre, une enveloppe convexe



		//S'il existe moins de 4 points -> impossible
		if (enveloppe.size()<4) {
			return null;
		}

		//Trouver les points d'abscisse minimum et maximum, d'ordonnee minimum et maximum
		Point pi=enveloppe.get(0); //abscisse minimum
		Point pj=enveloppe.get(1); //ordonnee minimum
		Point pk=enveloppe.get(2); //abscisse maximum
		Point pl=enveloppe.get(3); //ordonee maximum

		for(Point p1: enveloppe) {

			if(p1.x<pi.x) {
				pi=p1;

			}
			if(p1.y<pj.y) {
				pj=p1;

			}
			if(p1.x>pk.x) {
				pk=p1;

			}
			if(p1.y>pl.y) {
				pl=p1;

			}
		}

		//Test points confondu ici si probleme

		//Construire 4 droites passant par pi,pj,pk,pl

		Line line_i,line_j,line_k,line_l;


		//test des lignes avec vecteur
		line_l=new Line(pl,new Vecteur(-1,0));
		line_k=new Line(pk,new Vecteur(0,-1));
		line_i=new Line(pi,new Vecteur(0,1));
		line_j=new Line(pj,new Vecteur(1,0));



		//Creation de l'angle minimum pour chaque droites
		double angle_i;
		double angle_j;
		double angle_k;
		double angle_l;

		// recuperation des indices des points dans l'enveloppe convexe
		int index_pi=enveloppe.indexOf(pi);
		int index_pj=enveloppe.indexOf(pj);
		int index_pk=enveloppe.indexOf(pk);
		int index_pl=enveloppe.indexOf(pl);



		//Initialisation angle mininum
		double angle_min   = 0;


		//initialisation rectangle et Aire du rectangle

		Rectangle rec=new Rectangle(line_i,line_j,line_k,line_l);
		double airMin=Double.MAX_VALUE; //changer par res.calculAir?

		//Angle minimum selectionne:  left=0,right=1,top=2,bottom=3
		int selected=-1;

		// Tant que l'on n'a pas fini de parcourir l'enveloppe convexe.
		for(int i=0;i<enveloppe.size();i++) {

			//Creation de l'angle minimum pour chaque droites
			angle_i=Other.cos(line_i, new Line(enveloppe.get(index_pi),enveloppe.get((index_pi+1)%enveloppe.size()))); //gauche
			angle_j=Other.cos(line_j, new Line(enveloppe.get(index_pj),enveloppe.get((index_pj+1)%enveloppe.size()))); //bas
			angle_k=Other.cos(line_k, new Line(enveloppe.get(index_pk),enveloppe.get((index_pk+1)%enveloppe.size()))); //droite
			angle_l=Other.cos(line_l, new Line(enveloppe.get(index_pl),enveloppe.get((index_pl+1)%enveloppe.size()))); //haut
			
			//On recupere l'angle minimum entres chaqu'un des angles cree precedement (plus Cos augmente et plus l'angle diminue)
			if (angle_i > angle_j) {
				angle_min = angle_i;
				//index_angle_min = index_pi;
				selected=0;
			} else {
				angle_min = angle_j;
				//index_angle_min = index_pj;
				selected=3;
			}

			if (angle_k > angle_min) {
				angle_min = angle_k;
				//index_angle_min = index_pk;
				selected=1;
			}

			if (angle_l > angle_min) {
				angle_min = angle_l;
				//index_angle_min = index_pl;
				selected=2;
			}



			switch(selected) {

			case 0://gauche
				line_i=new Line(enveloppe.get(index_pi),enveloppe.get((index_pi+1)%enveloppe.size()));
				line_j=new Line(enveloppe.get(index_pj),line_i.getVec().normal().oppose()); 
				line_k=new Line(enveloppe.get(index_pk),line_i.getVec().oppose()); 
				line_l=new Line(enveloppe.get(index_pl),line_j.getVec().oppose());

				index_pi=(index_pi+1)%enveloppe.size();
				line_i.SetPoint(enveloppe.get(index_pi));

				break;

			case 3: //bottom
				line_j=new Line(enveloppe.get(index_pj),enveloppe.get((index_pj+1)%enveloppe.size()));
				line_k=new Line(enveloppe.get(index_pk),line_j.getVec().normal().oppose());
				line_l=new Line(enveloppe.get(index_pl),line_j.getVec().oppose());
				line_i=new Line(enveloppe.get(index_pi),line_k.getVec().oppose());

				index_pj=(index_pj+1)%enveloppe.size();
				line_j.SetPoint(enveloppe.get(index_pj));

				break;

			case 1: //right
				line_k=new Line(enveloppe.get(index_pk),enveloppe.get((index_pk+1)%enveloppe.size()));
				line_l=new Line(enveloppe.get(index_pl),line_k.getVec().normal().oppose());
				line_i=new Line(enveloppe.get(index_pi),line_k.getVec().oppose());
				line_j=new Line(enveloppe.get(index_pj),line_l.getVec().oppose());

				index_pk=(index_pk+1)%enveloppe.size();
				line_k.SetPoint(enveloppe.get(index_pk));

				break;

			default: //top
				line_l=new Line(enveloppe.get(index_pl),enveloppe.get((index_pl+1)%enveloppe.size()));
				line_i=new Line(enveloppe.get(index_pi),line_l.getVec().normal().oppose());
				line_j=new Line(enveloppe.get(index_pj),line_l.getVec().oppose());
				line_k=new Line(enveloppe.get(index_pk),line_i.getVec().oppose());

				index_pl=(index_pl+1)%enveloppe.size();
				line_l.SetPoint(enveloppe.get(index_pl));

				break;
			}

			// Calcul de l'air du Rectangle le plus petit
			Rectangle rec2 = new Rectangle(line_i, line_j, line_k, line_l);
			double AirRectangle=rec2.CalculAir();

			if (AirRectangle < airMin) {
				rec = rec2;
				airMin = AirRectangle;
			}

		}
		//complexite de rec.getPoints en O(4)

		return rec;
	}
	
	/*
	 * *************************
	 * Algorithme de Ritter    *
	 * *************************
	 */
	
	public Circle ritter(ArrayList<Point> points){ //note: Obliger d'utiliser des doubles car coordonnees parfois tres petite (0<?<1) pour alpha et beta

		//Prendre un point dummy dans la liste des points
		Point dummy=points.get(0);

		//Point p de distance maximum a dummy
		Point p = null;
		double distanceMax=-1;

		for (Point p1 : points) {
			double distance =dummy.distance(p1);
			if (distance > distanceMax) {   
				p= p1;
				distanceMax = distance;
			}
		}

		//Point q de distance maximum au point p
		Point q=null;
		distanceMax=-1; //Ne change pas?

		for (Point p2 : points) {
			double distance =  p.distance(p2);
			if (distance > distanceMax) { //ICi
				q= p2;
				distanceMax = distance;
			}
		}

		//Le point c, le centre du segment PQ
		double x=(p.x+q.x)/2;
		double y=(p.y+q.y)/2;

		Point c=new Point((int)x,(int)y);

		//Cercle 
		double cp; //rayon du cercle de centre c

		cp=Point.distance(x, y, p.x, p.y);


		//Notre liste de points
		ArrayList<Point> plist=new ArrayList<Point>();
		//On retire les points compris dans le cercle
		for(Point p3:points) {
			if(Point.distance(x, y, p3.x, p3.y)>cp) {
				plist.add(p3);
			}
		}
		// S'il ne reste plus de points dans la liste, on renvoie notre cercle de centre c
		if (plist.isEmpty()) {
			return new Circle(c, (int)cp);
		}

		Point ca=null; //C'
		Point s=null;

		//S'il reste des points

		while (!plist.isEmpty()) {

			ArrayList<Point> plist1 = new ArrayList<Point>();
			//S un point quelconque
			s=plist.get(0);
			plist.remove(s); // On le retire pour eviter de le confondre avec un autre point

			//Distance SC
			double sc= Point.distance(x, y, s.x, s.y);

			//Le point T est sur le cercle, on cherche C' (ca) le centre de ST
			double st=sc+cp; //distance des points S et T
			double sca=st/2; //C'
			double cca=sc-sca; //distance des points C et C'

			//Coordonnes barycentrique -> C'=alphaC+BetaS
			double alpha=sca/sc;
			double beta=cca/sc;
			double x1 = alpha * x + beta * s.x; //coordonnee x de C'
			double y1 = alpha * y + beta * s.y; //coordonnee y de C'

			ca = new Point((int)x1,(int)y1);
			for (Point p4 : plist) {
				if (Point.distance(x1, y1, p4.x, p4.y) > sca) {
					plist1.add(p4);
				}
			}
			if (plist1.isEmpty()) {
				return new Circle(ca, (int)sca);
			} else {
				plist = (ArrayList<Point>) plist1.clone();
				x = x1;
				y = y1;
				cp = sca;
			}
		}
		return new Circle(ca,(int)cp); 



	}

	
}


