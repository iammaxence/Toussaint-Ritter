// 
// Decompiled by Procyon v0.5.36
// 

package supportGUI;

public class Variables
{
    public static final String MAINPANEL = "1664";
    public static final Object lock;
    public static final Object lock2;
    
    static {
        lock = new Object();
        lock2 = new Object();
    }
}
