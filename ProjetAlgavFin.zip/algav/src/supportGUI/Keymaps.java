// 
// Decompiled by Procyon v0.5.36
// 

package supportGUI;

import java.awt.Point;
import java.awt.Color;
import java.util.ArrayList;

import algorithms.DefaultTeam;
import test.CalculesQualite;
import test.GraphsTest;
import tools.EnveloppeConvexe;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Keymaps implements KeyListener
{
    private RootPanel rootPanel;
    private int nbPoints;
    
    
    public Keymaps(final RootPanel rootPanel, final int nbPoints) {
        this.rootPanel = rootPanel;
        this.nbPoints = nbPoints;
    }
    
    @Override
    public void keyPressed(final KeyEvent arg0) {
    }
    
    @Override
    public void keyReleased(final KeyEvent arg0) {
    }
    
    @Override
    public void keyTyped(final KeyEvent event) {
        switch (event.getKeyChar()) {
            case 'h': {
                this.rootPanel.shiftLeftAll();
                break;
            }
            case 'j': {
                this.rootPanel.shiftUpAll();
                break;
            }
            case 'k': {
                this.rootPanel.shiftDownAll();
                break;
            }
            case 'l': {
                this.rootPanel.shiftRightAll();
                break;
            }
            case 't': {
            	final ArrayList<Point> env=EnveloppeConvexe.enveloppeConvexe((ArrayList)this.rootPanel.getPoints());
            	long t = System.currentTimeMillis();
                final ArrayList<Point> tous = (ArrayList<Point>)new DefaultTeam().toussaint(env).getPoints();
                t = System.currentTimeMillis() - t;
                this.rootPanel.addPolygoneAndT(tous, t);
                break;
            }
            case 'r': {
            	long t = System.currentTimeMillis();
                final tools.Circle rit = new DefaultTeam().ritter((ArrayList)this.rootPanel.getPoints());
                t = System.currentTimeMillis() - t;
                Circle c=new Circle(rit.centre, rit.rayon);
                this.rootPanel.addCircleAndT(c, t);
                break;
            }
           
            case 'e': {
                try {
                    long t = System.currentTimeMillis();
                    final ArrayList<Point> env = new EnveloppeConvexe().enveloppeConvexe((ArrayList)this.rootPanel.getPoints());
                    t = System.currentTimeMillis() - t;
                    this.rootPanel.addPolygoneAndT(env, t);
                    break;
                }
                catch (Exception ex) {}
            }
            case '1': {
                try {
                	GraphsTest.TimeOnPoint("Toussaint");
                    break;
                }
                catch (Exception ex) {}
            }
            case '2': {
                try {
                	GraphsTest.TimeOnPoint("Ritter");
                    break;
                }
                catch (Exception ex) {}
            }
            case '3': {
                try {
                	CalculesQualite.Results("Toussaint");
                    break;
                }
                catch (Exception ex) {}
            }
            case '4': {
                try {
                	CalculesQualite.Results("Ritter");
                    break;
                }
                catch (Exception ex) {}
            }
            case 'p': {
                try {
                	
                    RandomPointsGenerator.generate(this.nbPoints);
                    DiamRace.readFile();
                    this.rootPanel.refreshLine();
                }
                catch (Exception ex2) {}
                break;
            }
        }
    }
}
