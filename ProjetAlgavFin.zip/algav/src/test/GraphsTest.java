package test;

import java.awt.Point;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

import algorithms.DefaultTeam;
import tools.EnveloppeConvexe;
import tools.Other;
public class GraphsTest {
	
	
	
	public static void TimeOnPoint(String name) throws FileNotFoundException { //Create file with 
		final PrintStream output = new PrintStream(new FileOutputStream("GraphFiles/"+name+"_Algorithm.csv"));
		int nbpoints=0;
		long time=-1;
		//Read all the files in the folder which contain all the ".points" files
		File folder = new File("C:/Users/Maxence/git/algav/SamplesPoints"); //Les fichiers points contenue dans le dossier samples
		File[] listOfFiles = folder.listFiles();
		sortByNumber(listOfFiles);
		for (File file : listOfFiles) {
			
			
			ArrayList<Point> points=Other.getPointsFromFile(file);
			ArrayList<Point> env=EnveloppeConvexe.enveloppeConvexe(points);
			nbpoints=points.size();
			time = System.currentTimeMillis();
			//ArrayList<Point> env=EnveloppeConvexe.enveloppeConvexe(points);
			//ArrayList<Point> tous = (ArrayList<Point>)new DefaultTeam().toussaint(env).getPoints();
			tools.Circle rit = new DefaultTeam().ritter(points);
            long res = System.currentTimeMillis() - time;
            output.println(nbpoints+ "," +res);
         	
			
		}
		
		output.close();
	}
	
	//Pour trier dans l'ordre croissant les files des samples
	public static void sortByNumber(File[] files) {
        Arrays.sort(files, new Comparator<File>() {
            @Override
            public int compare(File o1, File o2) {
                int n1 = extractNumber(o1.getName());
                int n2 = extractNumber(o2.getName());
                return n1 - n2;
            }

            private int extractNumber(String name) {
                int i = 0;
                try {
                    int s = name.indexOf('_')+1;
                    int e = name.lastIndexOf('.');
                    String number = name.substring(s, e);
                    i = Integer.parseInt(number);
                } catch(Exception e) {
                    i = 0; // if filename does not match the format
                           // then default to 0
                }
                return i;
            }
        });

        for(File f : files) {
            System.out.println(f.getName());
        }
    }
	
	
}
