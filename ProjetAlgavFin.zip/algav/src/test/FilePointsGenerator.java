package test;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Random;

import supportGUI.RandomPointsGenerator;

public class FilePointsGenerator { //Generateur de points dans differents fichier (Pour les graphs)
	private static int numberOfPoints;
	private static int maxWidth=1400;
	private static int maxHeight=900;
	private static int radius=200;
	private static int nbFile=1664;
	
	
	//Creation des samples pour les test de performances (Attention : 3go de donnees)
	public static void main(String[] args) {
		filesPointsGenerator();
	}

	//Genere les samples pour les test de performance (Dossier SamplesPoints)
	
	public static void filesPointsGenerator() {
		try {
			for(int j=1;j<=nbFile;j++) { // Nombre de fichier voulu
				numberOfPoints=j*256; //Cree des points avec un pas de 256
				String filename="SamplesPoints/"+numberOfPoints+".points";
				final PrintStream output = new PrintStream(new FileOutputStream(filename));
				final Random generator = new Random();
				for (int i = 0; i < numberOfPoints; ++i) {
					int x;
					int y;
					do {
						x = generator.nextInt(maxWidth);
						y = generator.nextInt(maxHeight);
					} while (distanceToCenter(x, y) >= radius * 1.4 && (distanceToCenter(x, y) >= radius * 1.6 || generator.nextInt(5) != 1) && (distanceToCenter(x, y) >= radius * 1.8 || generator.nextInt(10) != 1) && (maxHeight / 5 >= x || x >= 4 * maxHeight / 5 || maxHeight / 5 >= y || y >= 4 * maxHeight / 5 || generator.nextInt(100) != 1));
					output.println(String.valueOf(Integer.toString(x)) + " " + Integer.toString(y));
				}
				output.close();
			}
		}
		catch (FileNotFoundException e) {
			System.err.println("I/O exception: unable to create your file " );
		}
	}

	public static double distanceToCenter(final int x, final int y) {
		return Math.sqrt(Math.pow(x - maxWidth / 2, 2.0) + Math.pow(y - maxHeight / 2, 2.0));
	}


}
