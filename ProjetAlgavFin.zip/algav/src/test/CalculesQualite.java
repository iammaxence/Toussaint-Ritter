package test;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;

import algorithms.DefaultTeam;
import tools.Circle;
import tools.EnveloppeConvexe;
import tools.Other;
import tools.Rectangle;

public class CalculesQualite {
	
	//Calcul de qualite 
	public static double Qualite(double Area,double PolyArea) {
		return (Area/PolyArea)-1; 
	}
	
	//Creation d'un fichier csv pour le calcul de qualite en fonction du nom de l'algorithme (Toussaint ou Ritter)
	
	public static void Results(String name) throws FileNotFoundException {
		final PrintStream output = new PrintStream(new FileOutputStream("./QualityFiles/"+name+"_Algorithm.csv"));
		output.println("Instances"+ " " +"Temps"+name);
		File folder = new File("./samples"); //Les fichiers points contenue dans le dossier samples
		File[] listOfFiles = folder.listFiles();
		//GraphsTest.sortByNumber(listOfFiles); //Trie la liste des fichiers parce que Eclipse est trop c*n
		DefaultTeam dt=new DefaultTeam();
		int numInstance=0;
		double moyenne=0;
		for (File file : listOfFiles) {

			if (file.isFile()) {
				ArrayList<Point> p=Other.getPointsFromFile(file);
				ArrayList<Point> env=EnveloppeConvexe.enveloppeConvexe(p);
				double airPoly=Other.polygonArea(env);
				double val;
				if(name.equals("Toussaint")) {
					Rectangle rec=dt.toussaint(EnveloppeConvexe.enveloppeConvexe(env));
					double airRec=rec.CalculAir();
					val=Qualite(airRec, airPoly);
					//System.out.println("AirRect = "+airRec+" AirEnv = "+airPoly+" qualite = "+val+"\n");
				}
				else {
					Circle c=dt.ritter(p);
					double airCircle=c.CalculAir();
					val=Qualite(airCircle, airPoly);
					//System.out.println("AirCircle = "+airCircle+" AirPoly = "+airPoly+" qualite = "+val2+"\n");
				}
				output.println(numInstance+ " " +val);
			}
			numInstance++;
		}
		output.close();
		
		//obtenir la qualite moyenne de toutes les instances
		double res=moyenne/numInstance;
		System.out.println("Moyenne : "+res); 
	}

	

}
