package tools;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import algorithms.DefaultTeam;
import test.CalculesQualite;

public class test {
	
	public static ArrayList<Point> getPointsFromFile(File file) {
		ArrayList<Point> points = new ArrayList<Point>();
		try {
			BufferedReader bReader = new BufferedReader(
					new FileReader(file));
			String line;
			String[] coordinates;
			while ((line = bReader.readLine()) != null) {
				coordinates = line.split(" ");
				points.add(new Point(Integer.parseInt(coordinates[0]),
						Integer.parseInt(coordinates[1])));
			}
		} catch (IOException e) {
			e.printStackTrace(System.err);

		}
		return points;
	}

	public static void main(String[] args) {
		/*
		Vecteur v=new Vecteur(0,1);
		v=v.normal().oppose();
		System.out.println(v.toString());
		*/
		/*
		ArrayList<Point> p=new ArrayList<>();
		p.add(new Point(5,1));
		p.add(new Point(-4,3));
		p.add(new Point(2,5));
		
		
		
		p=Other.TrieEnveloppeConvexe(p);
		for(Point e:p) {
			System.out.println("Point x= "+e.x+" y= "+e.y);
		}
		System.out.println("Aire polygone = "+Other.polygonArea(p));
		*/
		Point p1=new Point(-4, 2);
		Point p2=new Point(4, 2);
		
		Line l1= new Line(p1,new Vecteur(0, 1));
		Line l2= new Line(p2,new Vecteur(1, 0));
		System.out.println(Other.cos(l1, l2));
	
		
		//CalculesQualite.Results();
		
	}

}
