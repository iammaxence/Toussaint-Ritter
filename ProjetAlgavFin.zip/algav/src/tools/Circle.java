package tools;

import java.awt.Point;

public class Circle {
	public Point centre;
	public int rayon;
	
	public Circle(Point centre, int rayon) {
		this.centre = centre;
		this.rayon = rayon;
	}
	
	//Aire du cercle
	public double CalculAir(){
		return Math.PI * rayon * rayon;
	}
}
