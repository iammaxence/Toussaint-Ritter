package tools;

import java.awt.Point;
import java.util.ArrayList;

public class EnveloppeConvexe {

	//Algorithme de Graham modifier
	public static ArrayList<Point> enveloppeConvexe(ArrayList<Point> points){ //---->O(n)
        if (points.size()<4) return points;

        ArrayList<Point> result = TriePixel(points); //O(n)
        for (int i=1;i<result.size()+2;i++) { //O(n)
            Point p = result.get((i-1)%result.size());
            Point q = result.get(i%result.size());
            Point r = result.get((i+1)%(result.size()));
            if (crossProduct(p,q,p,r)>0) {
                result.remove(i%result.size());
                if (i==2) i=1;
                if (i>2) i-=2;
            }
        }
        return result;
    }
	
	private static ArrayList<Point> TriePixel(ArrayList<Point> points){ // ----->O(n)
        if (points.size()<4) return points; //O(1)
        int maxX=points.get(0).x;
        for (Point p: points) if (p.x>maxX) maxX=p.x; //O(n)
        Point[] maxY = new Point[maxX+1];
        Point[] minY = new Point[maxX+1];
        for (Point p: points) { //O(n)
            if (maxY[p.x]==null||p.y>maxY[p.x].y) maxY[p.x]=p;
            if (minY[p.x]==null||p.y<minY[p.x].y) minY[p.x]=p;
        }
        ArrayList<Point> result = new ArrayList<Point>();
        for (int i=0;i<maxX+1;i++) if (maxY[i]!=null) result.add(maxY[i]);
        for (int i=maxX;i>=0;i--) if (minY[i]!=null && !result.get(result.size()-1).equals(minY[i])) result.add(minY[i]);

        if (result.get(result.size()-1).equals(result.get(0))) result.remove(result.size()-1);

        return result;
    }
	
	private static double crossProduct(Point p, Point q, Point s, Point t){
		return ((q.x-p.x)*(t.y-s.y)-(q.y-p.y)*(t.x-s.x));
	}
	private static boolean triangleContientPoint(Point a, Point b, Point c, Point x) {
		double l1 = ((b.y-c.y)*(x.x-c.x)+(c.x-b.x)*(x.y-c.y))/(double)((b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y));
		double l2 = ((c.y-a.y)*(x.x-c.x)+(a.x-c.x)*(x.y-c.y))/(double)((b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y));
		double l3 = 1-l1-l2;
		return (0<l1 && l1<1 && 0<l2 && l2<1 && 0<l3 && l3<1);
	}
}
