package tools;




public class Vecteur {

	private double x;
	private double y;

	public Vecteur(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	public double getX() {
		return x;
	}
	public double getY() {
		return y;
	}
	
	//Longueur d'un vecteur 
	public double norme() {
		return Math.sqrt(x * x + y * y);
	}
	
	public double ProduitDeVecteur(Vecteur vec2) {
		return x * vec2.x + y * vec2.y;
	}
	
	
	public Vecteur normal() {
		return new Vecteur(-y, x);
	}

	
	public Vecteur oppose() {
		return normal().normal();
	}
	
	public String toString() {
		return "(" + x + "," + y + ")";
	}
	
}
