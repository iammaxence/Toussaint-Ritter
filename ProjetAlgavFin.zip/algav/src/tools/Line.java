package tools;

import java.awt.Point;
import java.util.Vector;


public class Line {
	private Point p;
	private Vecteur vec;

	public Line(Point p, Vecteur vec) {
		this.p=p;
		this.vec=vec;
	}

	public Line(Point p1, Point p2) {
		if (p1.x == p2.x) {
			vec = new Vecteur(0, 1);
		} else {
			vec = new Vecteur((p2.x - p1.x), (p2.y - p1.y));
		}
		p = p1;
	}
	
	
	
	public Point.Double intersection(Line line2) {
		double x,y;
		// Si la droite est vertical 
		
		if (vec.getX() == 0) {
			// Si la droite est vertical et que l'autre est aussi vertical, les droites sont opposees, on renvoie null
			if (line2.vec.getX() == 0) {
				return null;
			}
			
			// Si l'autre droite est horizonal alors creation d'un point de coordonnees-> x=notre point de droite vertical, y=coordonnee de l'autre point
			double ordALorgine=line2.p.getY()-line2.CoeffDirecteur()*line2.p.getX();
			
			return new Point.Double(p.getX(),
					(line2.CoeffDirecteur() * p.getX() + ordALorgine));
		}
		// Si la droite est horizontal et l'autre droite est verticale
		if (line2.vec.getX() == 0) {
			double ordALorgine=p.getY()-CoeffDirecteur()*p.getX();
			return new Point.Double(line2.p.getX(),
					(CoeffDirecteur() * line2.p.getX() +  ordALorgine));
		}
		// Si les deux droites sont parralleles entre elles
		if (line2.CoeffDirecteur() == CoeffDirecteur())
			return null;
		
		//Si vecteur coordonnes x =-1 -> Pas sur, a verifier/relire !!!
		double ordALorgineLine2=line2.p.getY()-line2.CoeffDirecteur()*line2.p.getX();
		double ordALorgine=p.getY()-CoeffDirecteur()*p.getX();
		
		x = (ordALorgineLine2 - ordALorgine) / (CoeffDirecteur() - line2.CoeffDirecteur());
		y = CoeffDirecteur() * x + ordALorgine;
		return new Point.Double(x, y);

	}
	
	public Vecteur getVec() {
		return vec;
	}
	
	public double CoeffDirecteur() {
		return vec.getY()/vec.getX();
		
	}
	
	
	public String toString() {
		return "Point = "+" ("+p.getX()+","+p.getY()+")";
	}
	
	public void SetPoint(Point p) {
		this.p=p;
	}
}
