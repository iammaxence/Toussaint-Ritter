package tools;

import java.awt.Point;
import java.util.ArrayList;


public class Rectangle {
	private Point.Double a,b,c,d;
	
	public Rectangle(Point.Double a,Point.Double b,Point.Double c,Point.Double d) {
		this.a=a;
		this.b=b;
		this.c=c;
		this.d=d;
	}
	
	public Rectangle(Line l1, Line l2, Line l3, Line l4) {
		this(l1.intersection(l2), l2.intersection(l3), l3.intersection(l4), l4
				.intersection(l1));
	}
	
	public ArrayList<Point> getPoints(){ //Obtenir une arrayList de points associe aux 4 points d'un rectangle
		ArrayList<Point.Double> p=new ArrayList<Point.Double>();
		
		p.add(a);
		p.add(b);
		p.add(c);
		p.add(d);
		
		//complexite en O(4)
		ArrayList<Point> p2=new ArrayList<Point>();
	    for (Point.Double e : p) {
	    	
	       p2.add(new Point((int)e.x,(int)e.y));
	    }
		return p2;
		
	}
	
	//Aire du rectangle = L*l
	public double CalculAir() {
		return b.distance(a) * b.distance(c);
	}
	
	public String toString() {
		return "Rectangle [a=" + a + ", b=" + b + ", c=" + c + ", d=" + d + "]";
	}
}
