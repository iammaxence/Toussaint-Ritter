package tools;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class Other {
	
	//Cosinus de l'angle entre deux lignes L1 et L2
	public static double cos(Line l1, Line l2) {
		//cosinus(u.v)=u*v/|u|*|v| avec u et v deux vecteurs
		double cos=l1.getVec().ProduitDeVecteur(l2.getVec())/(l1.getVec().norme()*(l2.getVec().norme()));
		return Math.abs(cos); //valeur absolue du cosinus
	}
	
	
	private static Point findCentroid(ArrayList<Point> points) { //Trouver le centre d'une liste de points
	    int x = 0;
	    int y = 0;
	    for (Point p : points) {
	        x += p.x;
	        y += p.y;
	    }
	    Point center = new Point(0, 0);
	    center.x = x / points.size();
	    center.y = y / points.size();
	    return center;
	}
	
	public static ArrayList<Point> sortVerticies(ArrayList<Point> points) { //trie une liste de points
	    
	    Point center = findCentroid(points);
	    Collections.sort(points, (a, b) -> {
	        double a1 = (Math.toDegrees(Math.atan2(a.x - center.x, a.y - center.y)) + 360) % 360;
	        double a2 = (Math.toDegrees(Math.atan2(b.x - center.x, b.y - center.y)) + 360) % 360;
	        return (int) (a1 - a2);
	    });
	    return points;
	}
	
	public static ArrayList<Point> TrieEnveloppeConvexe(ArrayList<Point> points) { //Renvoie la liste des points dans l'ordre inverse trigonometrique
	
		ArrayList<Point> ptrie=new ArrayList<>();
		for(int i=points.size()-1;i>=0;i--) {

			ptrie.add(points.get(i));
		}

		ptrie.add(ptrie.get(0));
		
		//
		return ptrie;
	}
	
	public static int polygonArea(ArrayList<Point> points)  //Renvoie l'air du polygone convexe
	{ 
		ArrayList<Point> p=TrieEnveloppeConvexe(points);
		//Initialisation
		int a1=0;
		int a2=0;
		int area=0;
		
		for(int i=0;i<p.size();i++) {
			a1+=p.get(i).x * p.get((i+1)%p.size()).y;
			a2+=p.get(i).y * p.get((i+1)%p.size()).x;
		}
		area=a1-a2;
		return Math.abs(area/2);

	}
	
	public static ArrayList<Point> getPointsFromFile(File file) {
		ArrayList<Point> points = new ArrayList<Point>();
		try {
			BufferedReader bReader = new BufferedReader(
					new FileReader(file));
			String line;
			String[] coordinates;
			while ((line = bReader.readLine()) != null) {
				coordinates = line.split(" ");
				points.add(new Point(Integer.parseInt(coordinates[0]),
						Integer.parseInt(coordinates[1])));
			}
			bReader.close();
		} catch (IOException e) {
			e.printStackTrace(System.err);

		}
		
		return points;
	}
}
